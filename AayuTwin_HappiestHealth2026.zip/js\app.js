/**
 * AAYU-TWIN Main Application Orchestrator
 * Connects EHR ingestion, Wearable telemetry streaming, Biophysical ODE solver,
 * Adverse event predictor, Holographic visualizer, and Clinical reporting.
 */

window.AayuApp = (function() {
  let patients = [];
  let currentPatient = null;
  let baselineSimulation = null;
  let counterfactualSimulation = null;
  let audioEnabled = false;
  let audioCtx = null;

  // Embedded fallback data in case server is not running
  const FALLBACK_PATIENTS = [
    {
      "id": "IN-P-2026-081",
      "name": "Rajesh Kumar",
      "abhaId": "91-4521-8839-0129@abdm",
      "age": 46,
      "gender": "Male",
      "location": "Bengaluru, Karnataka",
      "occupation": "Senior Software Architect (Sedentary, High-Stress)",
      "archetype": "Uncontrolled T2D + Nocturnal Hypertension (Indian Phenotype)",
      "anthropometrics": { "bmi": 26.4, "waistCircumferenceCm": 94 },
      "vitalsBaseline": { "systolicBp": 144, "diastolicBp": 92, "restingHeartRate": 82, "hrvRmssd": 22.4, "pulseWaveVelocity": 9.4 },
      "labBiomarkers": { "hba1c": 8.6, "fastingPlasmaGlucose": 172, "fastingInsulin": 24.8, "homaIr": 10.5, "homaBeta": 42.1, "estimatedGfr": 78, "uacr": 48.2, "liverEnzymes": { "altSgpt": 58, "astSgot": 46 } },
      "dietaryLifestyleProfile": { "dietPattern": "High Glycemic South Indian", "averageDailySteps": 3200, "sleepDurationHours": 5.8, "chronicStressIndex": 8.2 },
      "digitalTwinParameters": { "insulinSensitivitySI": 0.00042, "betaCellCapacity": 0.48, "glucoseClearanceP1": 0.024, "arterialComplianceC": 0.88, "renalHyperfiltrationIndex": 1.34, "hepaticSteatosisProbability": 0.76 }
    },
    {
      "id": "IN-P-2026-144",
      "name": "Sunita Sharma",
      "abhaId": "91-7712-4402-9915@abdm",
      "age": 54,
      "gender": "Female",
      "location": "New Delhi, NCR",
      "occupation": "School Principal / Homemaker",
      "archetype": "Long-standing T2D + Microalbuminuria Risk",
      "anthropometrics": { "bmi": 28.1, "waistCircumferenceCm": 91 },
      "vitalsBaseline": { "systolicBp": 138, "diastolicBp": 86, "restingHeartRate": 78, "hrvRmssd": 19.8, "pulseWaveVelocity": 10.1 },
      "labBiomarkers": { "hba1c": 9.1, "fastingPlasmaGlucose": 188, "fastingInsulin": 14.2, "homaIr": 6.6, "homaBeta": 24.5, "estimatedGfr": 64, "uacr": 112.5, "liverEnzymes": { "altSgpt": 38, "astSgot": 32 } },
      "dietaryLifestyleProfile": { "dietPattern": "Traditional Vegetarian", "averageDailySteps": 2800, "sleepDurationHours": 6.2, "chronicStressIndex": 6.4 },
      "digitalTwinParameters": { "insulinSensitivitySI": 0.00038, "betaCellCapacity": 0.28, "glucoseClearanceP1": 0.021, "arterialComplianceC": 0.79, "renalHyperfiltrationIndex": 1.58, "hepaticSteatosisProbability": 0.62 }
    },
    {
      "id": "IN-P-2026-302",
      "name": "Dr. Arjun Nair",
      "abhaId": "91-3309-1245-7761@abdm",
      "age": 34,
      "gender": "Male",
      "location": "Hyderabad, Telangana",
      "occupation": "Biotech Founder / Startup Executive",
      "archetype": "Early-Stage Pre-Diabetes in Young Indian (CVD Family Risk)",
      "anthropometrics": { "bmi": 24.1, "waistCircumferenceCm": 88 },
      "vitalsBaseline": { "systolicBp": 128, "diastolicBp": 84, "restingHeartRate": 84, "hrvRmssd": 28.5, "pulseWaveVelocity": 8.1 },
      "labBiomarkers": { "hba1c": 6.2, "fastingPlasmaGlucose": 112, "fastingInsulin": 28.6, "homaIr": 7.9, "homaBeta": 110.2, "estimatedGfr": 114, "uacr": 18.0, "liverEnzymes": { "altSgpt": 44, "astSgot": 36 } },
      "dietaryLifestyleProfile": { "dietPattern": "Irregular Urban Dining", "averageDailySteps": 4500, "sleepDurationHours": 5.4, "chronicStressIndex": 9.1 },
      "digitalTwinParameters": { "insulinSensitivitySI": 0.00055, "betaCellCapacity": 0.89, "glucoseClearanceP1": 0.028, "arterialComplianceC": 0.98, "renalHyperfiltrationIndex": 1.12, "hepaticSteatosisProbability": 0.58 }
    }
  ];

  async function init() {
    await loadPatientData();
    setupHeaderControls();
    
    // Initialize Subsystems
    AayuTelemetryCharts.initCgmChart('cgmChartCanvas');
    AayuTelemetryCharts.initEcgMonitor('ecgCanvasMonitor');
    AayuDigitalTwinVis.init('anatomicalVisContainer');

    AayuWhatIfSimulator.init('sandboxContainer', (intervention) => {
      runCounterfactualSimulation(intervention);
    });

    selectPatient(patients[0].id);
    startLiveClock();
  }

  async function loadPatientData() {
    try {
      const res = await fetch('/api/patients');
      if (res.ok) {
        patients = await res.json();
      } else {
        patients = FALLBACK_PATIENTS;
      }
    } catch (e) {
      patients = FALLBACK_PATIENTS;
    }

    const selectEl = document.getElementById('patientSelect');
    if (selectEl) {
      selectEl.innerHTML = patients.map(p => `
        <option value="${p.id}">${p.name} (${p.age}Y, ${p.location.split(',')[0]}) - ${p.archetype.split('+')[0]}</option>
      `).join('');

      selectEl.addEventListener('change', (e) => {
        selectPatient(e.target.value);
      });
    }
  }

  function setupHeaderControls() {
    // Sound FX toggle
    const audioBtn = document.getElementById('audioToggleBtn');
    if (audioBtn) {
      audioBtn.addEventListener('click', () => {
        audioEnabled = !audioEnabled;
        audioBtn.classList.toggle('active', audioEnabled);
        audioBtn.textContent = audioEnabled ? '🔊 Audio: On' : '🔇 Audio: Muted';
        if (audioEnabled && !audioCtx) {
          audioCtx = new (window.AudioContext || window.webkitAudioContext)();
          playBeep(880, 0.08); // short confirm chime
        }
      });
    }

    // ABDM FHIR Button
    const btnFhir = document.getElementById('btnExportFhir');
    if (btnFhir) {
      btnFhir.addEventListener('click', () => {
        const intervention = AayuWhatIfSimulator.getInterventionState();
        AayuFhirExporter.downloadFhirJson(currentPatient, baselineSimulation.metrics, counterfactualSimulation.metrics, intervention);
      });
    }

    // Clinical Report Button
    const btnReport = document.getElementById('btnClinicalReport');
    if (btnReport) {
      btnReport.addEventListener('click', () => {
        const intervention = AayuWhatIfSimulator.getInterventionState();
        AayuFhirExporter.showClinicalReportModal(currentPatient, baselineSimulation.metrics, counterfactualSimulation.metrics, intervention);
      });
    }
  }

  function selectPatient(patientId) {
    currentPatient = patients.find(p => p.id === patientId) || patients[0];
    updatePatientHeaderInfo();
    
    // Run baseline simulation
    baselineSimulation = AayuBiophysicalEngine.simulate(currentPatient, {});
    
    // Run counterfactual with currently active simulator sliders
    const intervention = AayuWhatIfSimulator.getInterventionState();
    runCounterfactualSimulation(intervention);

    // Update Adverse Event Banner
    updateAdverseEvents();
  }

  function updatePatientHeaderInfo() {
    if (!currentPatient) return;
    document.getElementById('headerPatientName').textContent = currentPatient.name;
    document.getElementById('headerPatientMeta').textContent = `${currentPatient.age} Yrs • ${currentPatient.gender} • BMI ${currentPatient.anthropometrics.bmi} • ${currentPatient.location}`;
    document.getElementById('headerAbhaId').textContent = currentPatient.abhaId;
    document.getElementById('patientArchetypeBadge').textContent = currentPatient.archetype;

    // Vitals Row
    document.getElementById('vitalSysBp').textContent = currentPatient.vitalsBaseline.systolicBp;
    document.getElementById('vitalDiaBp').textContent = currentPatient.vitalsBaseline.diastolicBp;
    document.getElementById('vitalHr').textContent = currentPatient.vitalsBaseline.restingHeartRate;
    document.getElementById('vitalHrv').textContent = `${currentPatient.vitalsBaseline.hrvRmssd} ms`;
    document.getElementById('vitalA1c').textContent = `${currentPatient.labBiomarkers.hba1c}%`;
    document.getElementById('vitalGfr').textContent = `${currentPatient.labBiomarkers.estimatedGfr} mL/min`;
  }

  function runCounterfactualSimulation(intervention) {
    if (!currentPatient) return;
    counterfactualSimulation = AayuBiophysicalEngine.simulate(currentPatient, intervention);
    
    // Redraw CGM Canvas with Baseline + Counterfactual Curve
    AayuTelemetryCharts.drawCgm(
      baselineSimulation.timeline,
      baselineSimulation.glucoseMgDl,
      counterfactualSimulation.glucoseMgDl
    );

    // Update Holographic visualizer with current metrics
    AayuDigitalTwinVis.update(currentPatient, counterfactualSimulation.metrics);

    // Update Deltas in Sandbox
    AayuWhatIfSimulator.updateDeltas(baselineSimulation.metrics, counterfactualSimulation.metrics);
  }

  function updateAdverseEvents() {
    if (!currentPatient) return;
    const banner = document.getElementById('adverseAlertBanner');
    if (!banner) return;

    if (currentPatient.id === "IN-P-2026-081") { // Rajesh
      banner.className = "alert-banner critical";
      banner.innerHTML = `
        <div class="alert-icon-box">⚠️</div>
        <div class="alert-content">
          <div class="alert-title-row">
            <span class="alert-badge critical">PREDICTED ADVERSE EVENT: IN 112 MINS</span>
            <span class="alert-event-name">Acute Postprandial Hyperglycemic Surge (&gt;245 mg/dL)</span>
            <span class="alert-prob">Confidence: 94.2%</span>
          </div>
          <div class="alert-desc">
            Multi-modal fusion (CGM slope +1.8 mg/dL/min + dinner carb load 85g + low nocturnal HRV 22ms) forecasts runaway glucose spike.
          </div>
          <div class="alert-shap-tags">
            <span class="shap-tag red">High Indian Carb Load (+68 mg/dL)</span>
            <span class="shap-tag red">HOMA-IR 10.5 Resistance (+42 mg/dL)</span>
            <span class="shap-tag yellow">Sympathetic Autonomic Tone (Cortisol)</span>
            <span class="shap-tag blue">Mitigation: 20-min Post-Dinner Walk blunts spike by -48 mg/dL</span>
          </div>
        </div>
        <div class="alert-actions">
          <button class="btn-alert-action" id="btnApplyPrescription">⚡ Apply Counterfactual Orders</button>
        </div>
      `;

      if (audioEnabled) playAlertChime();

      document.getElementById('btnApplyPrescription').addEventListener('click', () => {
        document.getElementById('btnPresetSglt2Lifestyle').click();
      });

    } else if (currentPatient.id === "IN-P-2026-144") { // Sunita
      banner.className = "alert-banner warning";
      banner.innerHTML = `
        <div class="alert-icon-box">⚡</div>
        <div class="alert-content">
          <div class="alert-title-row">
            <span class="alert-badge warning">RENAL ADVERSE EVENT WARNING</span>
            <span class="alert-event-name">Glomerular Hyperfiltration Stress (1.58x Basal Load)</span>
            <span class="alert-prob">Microalbuminuria UACR 112.5 mg/g</span>
          </div>
          <div class="alert-desc">
            Sustained postprandial glucose &gt; 220 mg/dL combined with 138 mmHg systolic pressure creates endothelial shear stress, accelerating nephron decline.
          </div>
          <div class="alert-shap-tags">
            <span class="shap-tag red">Attenuated Beta-Cell Secretion (-32%)</span>
            <span class="shap-tag red">Renal Hyperfiltration Shear Stress</span>
            <span class="shap-tag green">Action: SGLT2i Induces Intraglomerular Pressure Decompression</span>
          </div>
        </div>
        <div class="alert-actions">
          <button class="btn-alert-action" id="btnApplySunitaOrders">⚡ Prescribe SGLT2i + Metformin</button>
        </div>
      `;

      document.getElementById('btnApplySunitaOrders').addEventListener('click', () => {
        document.getElementById('checkSglt2').checked = true;
        document.getElementById('cardSglt2').classList.add('active');
        const intervention = AayuWhatIfSimulator.getInterventionState();
        runCounterfactualSimulation(intervention);
      });

    } else { // Dr. Arjun
      banner.className = "alert-banner info";
      banner.innerHTML = `
        <div class="alert-icon-box">ℹ️</div>
        <div class="alert-content">
          <div class="alert-title-row">
            <span class="alert-badge info">PRE-DIABETIC CARDIOMETABOLIC ALERT</span>
            <span class="alert-event-name">Sympathetic Autonomic Overdrive &amp; Thin-Fat Phenotype</span>
            <span class="alert-prob">Pre-diabetes (HbA1c 6.2%, HOMA-IR 7.9)</span>
          </div>
          <div class="alert-desc">
            High chronic stress (9.1/10) and late dining drive hyperinsulinemic compensation. 10-year premature CAD risk elevated due to family history.
          </div>
          <div class="alert-shap-tags">
            <span class="shap-tag yellow">Sleep Debt: 2.1 hrs</span>
            <span class="shap-tag yellow">High Fasting Insulin (28.6 uU/mL)</span>
            <span class="shap-tag green">Reversible via Circadian Synchronization &amp; Low-GI Diet</span>
          </div>
        </div>
        <div class="alert-actions">
          <button class="btn-alert-action" id="btnApplyArjunOrders">⚡ Initiate Lifestyle Protocol</button>
        </div>
      `;

      document.getElementById('btnApplyArjunOrders').addEventListener('click', () => {
        document.getElementById('btnPresetSglt2Lifestyle').click();
      });
    }
  }

  function startLiveClock() {
    const clockEl = document.getElementById('liveClockTime');
    if (!clockEl) return;
    setInterval(() => {
      const now = new Date();
      clockEl.textContent = now.toLocaleTimeString('en-IN', { hour12: false });
    }, 1000);
  }

  // Audio Synthesizers
  function playBeep(freq = 750, dur = 0.06) {
    if (!audioEnabled || !audioCtx) return;
    try {
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.04, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + dur);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + dur);
    } catch(e) {}
  }

  function playAlertChime() {
    if (!audioEnabled || !audioCtx) return;
    try {
      [580, 880].forEach((freq, idx) => {
        setTimeout(() => playBeep(freq, 0.12), idx * 120);
      });
    } catch(e) {}
  }

  return {
    init,
    selectPatient
  };
})();

// Bootstrap on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  AayuApp.init();
});
