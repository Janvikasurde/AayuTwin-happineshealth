/**
 * AAYU-TWIN Counterfactual "What-If" Simulation Playground
 * Interactive sandbox allowing clinicians to test pharmacological, dietary,
 * physical exercise, and circadian interventions and immediately observe
 * the simulated Digital Twin's multi-organ trajectories.
 */

window.AayuWhatIfSimulator = (function() {
  let onSimulationUpdateCallback = null;

  function init(containerId, onUpdate) {
    onSimulationUpdateCallback = onUpdate;
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = `
      <div class="sandbox-card">
        <div class="sandbox-header">
          <div class="sandbox-title-wrap">
            <span class="pulse-indicator"></span>
            <h3 class="sandbox-title">COUNTERFACTUAL "WHAT-IF" SANDBOX</h3>
          </div>
          <span class="sandbox-badge">Biophysical ODE Solver</span>
        </div>
        <p class="sandbox-subtitle">Simulate multi-organ response before prescribing clinical or lifestyle interventions.</p>

        <!-- Interventions Form -->
        <div class="interventions-grid">
          <!-- 1. Dietary Carbohydrate & Glycemic Load -->
          <div class="intervention-group">
            <div class="group-header">
              <span class="group-icon">🍚</span>
              <span class="group-label">Indian Diet & Glycemic Load</span>
              <span class="slider-val" id="carbDeltaVal">0%</span>
            </div>
            <input type="range" class="custom-range" id="carbDeltaSlider" min="-40" max="30" step="5" value="0">
            <div class="range-labels">
              <span>-40% (Keto/Low Carb)</span>
              <span>Baseline</span>
              <span>+30% (High Carb)</span>
            </div>
            
            <div class="sub-toggle-row">
              <label class="toggle-sublabel">Meal Glycemic Index:</label>
              <select class="custom-select" id="giSelect">
                <option value="0">Baseline (High GI: Polished Rice / Maida Roti)</option>
                <option value="-15">Medium GI (Whole Wheat / Brown Rice / Mixed Dal)</option>
                <option value="-25">Low GI (Millet / Ragi / Fenugreek / Sprouted Salad)</option>
              </select>
            </div>
          </div>

          <!-- 2. Physical Activity & Postprandial Walk -->
          <div class="intervention-group">
            <div class="group-header">
              <span class="group-icon">🚶</span>
              <span class="group-label">Postprandial Brisk Walking</span>
              <span class="slider-val" id="walkMinsVal">0 mins</span>
            </div>
            <input type="range" class="custom-range" id="walkMinsSlider" min="0" max="45" step="5" value="0">
            <div class="range-labels">
              <span>Sedentary (0m)</span>
              <span>15m Post-Meal</span>
              <span>30m</span>
              <span>45m (Active)</span>
            </div>
            <div class="feature-tag">Triggers insulin-independent muscle GLUT4 translocation</div>
          </div>

          <!-- 3. Pharmacological Regimen Optimization -->
          <div class="intervention-group">
            <div class="group-header">
              <span class="group-icon">💊</span>
              <span class="group-label">Precision Pharmacotherapy</span>
            </div>
            <div class="med-toggles-grid">
              <label class="med-toggle-card" id="cardSglt2">
                <input type="checkbox" id="checkSglt2">
                <div class="med-info">
                  <div class="med-name">SGLT2 Inhibitor</div>
                  <div class="med-sub">Dapagliflozin 10mg OD (Cardio-Renal Protection)</div>
                </div>
              </label>

              <label class="med-toggle-card active" id="cardMetformin">
                <input type="checkbox" id="checkMetformin" checked>
                <div class="med-info">
                  <div class="med-name">Metformin Extended Release</div>
                  <div class="med-sub">1000mg BID (Suppresses Hepatic Gluconeogenesis)</div>
                </div>
              </label>

              <label class="med-toggle-card" id="cardGlp1">
                <input type="checkbox" id="checkGlp1">
                <div class="med-info">
                  <div class="med-name">GLP-1 Receptor Agonist</div>
                  <div class="med-sub">Semaglutide 0.5mg QW (Beta-Cell Augmentation)</div>
                </div>
              </label>
            </div>
          </div>
        </div>

        <!-- Simulation Comparison Deltas -->
        <div class="delta-summary-banner" id="deltaBanner">
          <div class="delta-metric">
            <span class="delta-label">Time-in-Range (70-180)</span>
            <span class="delta-value positive" id="deltaTir">+0.0%</span>
          </div>
          <div class="delta-metric">
            <span class="delta-label">Mean Daily Glucose</span>
            <span class="delta-value" id="deltaMeanG">0.0 mg/dL</span>
          </div>
          <div class="delta-metric">
            <span class="delta-label">Estimated HbA1c</span>
            <span class="delta-value" id="deltaA1c">-0.0%</span>
          </div>
          <div class="delta-metric">
            <span class="delta-label">Systolic BP</span>
            <span class="delta-value" id="deltaBp">-0.0 mmHg</span>
          </div>
          <div class="delta-metric">
            <span class="delta-label">10-Yr CVD Risk</span>
            <span class="delta-value" id="deltaCvd">-0.0%</span>
          </div>
        </div>

        <!-- 1-Click Preset Clinical Scenarios -->
        <div class="presets-row">
          <span class="presets-label">1-Click Presets:</span>
          <button class="preset-btn" id="btnPresetSglt2Lifestyle">SGLT2i + 20m Walk + Millets</button>
          <button class="preset-btn" id="btnPresetAggressiveTriple">Triple Oral (SGLT2i + Met + GLP1)</button>
          <button class="preset-btn" id="btnPresetReset">Reset Baseline</button>
        </div>
      </div>
    `;

    bindEvents();
    triggerSimulation();
  }

  function bindEvents() {
    const carbSlider = document.getElementById('carbDeltaSlider');
    const carbVal = document.getElementById('carbDeltaVal');
    const giSelect = document.getElementById('giSelect');
    const walkSlider = document.getElementById('walkMinsSlider');
    const walkVal = document.getElementById('walkMinsVal');
    const checkSglt2 = document.getElementById('checkSglt2');
    const checkMetformin = document.getElementById('checkMetformin');
    const checkGlp1 = document.getElementById('checkGlp1');

    carbSlider.addEventListener('input', () => {
      let v = parseInt(carbSlider.value);
      carbVal.textContent = (v > 0 ? `+${v}%` : `${v}%`);
      triggerSimulation();
    });

    walkSlider.addEventListener('input', () => {
      let v = parseInt(walkSlider.value);
      walkVal.textContent = `${v} mins`;
      triggerSimulation();
    });

    giSelect.addEventListener('change', triggerSimulation);

    [checkSglt2, checkMetformin, checkGlp1].forEach(chk => {
      chk.addEventListener('change', () => {
        chk.closest('.med-toggle-card').classList.toggle('active', chk.checked);
        triggerSimulation();
      });
    });

    // Preset Buttons
    document.getElementById('btnPresetSglt2Lifestyle').addEventListener('click', () => {
      carbSlider.value = -20;
      carbVal.textContent = "-20%";
      giSelect.value = -25;
      walkSlider.value = 20;
      walkVal.textContent = "20 mins";
      checkSglt2.checked = true;
      document.getElementById('cardSglt2').classList.add('active');
      triggerSimulation();
    });

    document.getElementById('btnPresetAggressiveTriple').addEventListener('click', () => {
      carbSlider.value = -15;
      carbVal.textContent = "-15%";
      giSelect.value = -15;
      walkSlider.value = 15;
      walkVal.textContent = "15 mins";
      checkSglt2.checked = true;
      checkMetformin.checked = true;
      checkGlp1.checked = true;
      document.getElementById('cardSglt2').classList.add('active');
      document.getElementById('cardMetformin').classList.add('active');
      document.getElementById('cardGlp1').classList.add('active');
      triggerSimulation();
    });

    document.getElementById('btnPresetReset').addEventListener('click', () => {
      carbSlider.value = 0;
      carbVal.textContent = "0%";
      giSelect.value = 0;
      walkSlider.value = 0;
      walkVal.textContent = "0 mins";
      checkSglt2.checked = false;
      checkMetformin.checked = true;
      checkGlp1.checked = false;
      document.getElementById('cardSglt2').classList.remove('active');
      document.getElementById('cardMetformin').classList.add('active');
      document.getElementById('cardGlp1').classList.remove('active');
      triggerSimulation();
    });
  }

  function getInterventionState() {
    return {
      carb_intake_percent_delta: parseInt(document.getElementById('carbDeltaSlider').value),
      glycemic_index_delta: parseInt(document.getElementById('giSelect').value),
      post_meal_walk_minutes: parseInt(document.getElementById('walkMinsSlider').value),
      med_sglt2i: document.getElementById('checkSglt2').checked,
      med_metformin: document.getElementById('checkMetformin').checked,
      med_glp1: document.getElementById('checkGlp1').checked
    };
  }

  function triggerSimulation() {
    const intervention = getInterventionState();
    if (onSimulationUpdateCallback) {
      onSimulationUpdateCallback(intervention);
    }
  }

  function updateDeltas(baselineMetrics, counterfactualMetrics) {
    const deltaTir = counterfactualMetrics.timeInRangePercent - baselineMetrics.timeInRangePercent;
    const deltaMeanG = counterfactualMetrics.meanGlucoseMgDl - baselineMetrics.meanGlucoseMgDl;
    const deltaA1c = counterfactualMetrics.estimatedA1c - baselineMetrics.estimatedA1c;
    const deltaBp = baselineMetrics.systolicBpMmHg - counterfactualMetrics.systolicBpMmHg;
    const deltaCvd = baselineMetrics.cvdRisk10YearPercent - counterfactualMetrics.cvdRisk10YearPercent;

    const elTir = document.getElementById('deltaTir');
    const elMeanG = document.getElementById('deltaMeanG');
    const elA1c = document.getElementById('deltaA1c');
    const elBp = document.getElementById('deltaBp');
    const elCvd = document.getElementById('deltaCvd');

    if (elTir) {
      elTir.textContent = `${deltaTir >= 0 ? '+' : ''}${deltaTir.toFixed(1)}%`;
      elTir.className = `delta-value ${deltaTir >= 0 ? 'positive' : 'negative'}`;
    }
    if (elMeanG) {
      elMeanG.textContent = `${deltaMeanG >= 0 ? '+' : ''}${deltaMeanG.toFixed(1)} mg/dL`;
      elMeanG.className = `delta-value ${deltaMeanG <= 0 ? 'positive' : 'negative'}`;
    }
    if (elA1c) {
      elA1c.textContent = `${deltaA1c >= 0 ? '+' : ''}${deltaA1c.toFixed(2)}%`;
      elA1c.className = `delta-value ${deltaA1c <= 0 ? 'positive' : 'negative'}`;
    }
    if (elBp) {
      elBp.textContent = `-${deltaBp.toFixed(1)} mmHg`;
      elBp.className = `delta-value ${deltaBp >= 0 ? 'positive' : 'negative'}`;
    }
    if (elCvd) {
      elCvd.textContent = `-${deltaCvd.toFixed(1)}%`;
      elCvd.className = `delta-value ${deltaCvd >= 0 ? 'positive' : 'negative'}`;
    }
  }

  return {
    init,
    updateDeltas,
    getInterventionState
  };
})();
