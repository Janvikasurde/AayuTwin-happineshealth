/**
 * AAYU-TWIN Telemetry & Predictive Visualization Canvas Engine
 * Renders:
 * 1. 24-Hour CGM Stream + 2-Hour Predictive Forecast Cone
 * 2. Real-time Sweeping ECG/PPG Phosphor Canvas
 * 3. Hemodynamic & Glycemic Variability Gauges
 */

window.AayuTelemetryCharts = (function() {
  let cgmCanvas, cgmCtx;
  let ecgCanvas, ecgCtx;
  let ecgAnimId = null;
  let ecgX = 0;
  let lastEcgY = 0;

  function initCgmChart(canvasId) {
    cgmCanvas = document.getElementById(canvasId);
    if (!cgmCanvas) return;
    cgmCtx = cgmCanvas.getContext('2d');
    resizeCanvas(cgmCanvas);
    window.addEventListener('resize', () => {
      resizeCanvas(cgmCanvas);
      if (lastCgmData) drawCgm(lastCgmData.timeline, lastCgmData.glucose, lastCgmData.simulated);
    });
  }

  function resizeCanvas(canvas) {
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
  }

  let lastCgmData = null;

  function drawCgm(timeline, baselineGlucose, simulatedGlucose = null, forecastIndex = 260) {
    if (!cgmCanvas || !cgmCtx) return;
    lastCgmData = { timeline, glucose: baselineGlucose, simulated: simulatedGlucose };

    const rect = cgmCanvas.getBoundingClientRect();
    const w = rect.width;
    const h = rect.height;
    const ctx = cgmCtx;

    ctx.clearRect(0, 0, w, h);

    const padLeft = 45;
    const padRight = 30;
    const padTop = 25;
    const padBottom = 30;

    const plotW = w - padLeft - padRight;
    const plotH = h - padTop - padBottom;

    const minG = 40;
    const maxG = 320;

    function getY(val) {
      return padTop + plotH - ((val - minG) / (maxG - minG)) * plotH;
    }

    function getX(idx, total) {
      return padLeft + (idx / (total - 1)) * plotW;
    }

    // 1. Draw Target In-Range Safe Zone (70 to 180 mg/dL)
    const y180 = getY(180);
    const y70 = getY(70);
    ctx.fillStyle = 'rgba(0, 245, 155, 0.08)';
    ctx.fillRect(padLeft, y180, plotW, y70 - y180);

    // Hyperglycemic alert zone (>220)
    const y220 = getY(220);
    ctx.fillStyle = 'rgba(255, 42, 109, 0.06)';
    ctx.fillRect(padLeft, padTop, plotW, y220 - padTop);

    // Hypoglycemic alert zone (<70)
    ctx.fillStyle = 'rgba(255, 183, 3, 0.08)';
    ctx.fillRect(padLeft, y70, plotW, getY(minG) - y70);

    // 2. Horizontal Grid Lines & Threshold Labels
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);

    const thresholds = [
      { val: 70, color: 'rgba(255, 183, 3, 0.6)', label: '70 (Hypo)' },
      { val: 140, color: 'rgba(255, 255, 255, 0.15)', label: '140' },
      { val: 180, color: 'rgba(0, 245, 155, 0.6)', label: '180 (TIR Target)' },
      { val: 220, color: 'rgba(255, 42, 109, 0.6)', label: '220 (Spike Alert)' }
    ];

    thresholds.forEach(t => {
      const y = getY(t.val);
      ctx.strokeStyle = t.color;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(padLeft + plotW, y);
      ctx.stroke();

      ctx.font = '10px Inter, monospace';
      ctx.fillStyle = t.color;
      ctx.textAlign = 'right';
      ctx.fillText(t.label, padLeft - 6, y + 3);
    });

    ctx.setLineDash([]);

    const totalPts = baselineGlucose.length;

    // 3. Draw Baseline CGM Trace (Past Telemetry)
    ctx.beginPath();
    ctx.strokeStyle = '#00f0ff';
    ctx.lineWidth = 2.4;
    ctx.shadowColor = 'rgba(0, 240, 255, 0.5)';
    ctx.shadowBlur = 8;

    for (let i = 0; i < totalPts; i++) {
      const x = getX(i, totalPts);
      const y = getY(baselineGlucose[i]);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.shadowBlur = 0;

    // 4. Draw Counterfactual Twin Trace (if active)
    if (simulatedGlucose && simulatedGlucose.length > 0) {
      ctx.beginPath();
      ctx.strokeStyle = '#00f59b';
      ctx.lineWidth = 2.2;
      ctx.setLineDash([6, 3]);
      ctx.shadowColor = 'rgba(0, 245, 155, 0.6)';
      ctx.shadowBlur = 6;

      for (let i = 0; i < simulatedGlucose.length; i++) {
        const x = getX(i, simulatedGlucose.length);
        const y = getY(simulatedGlucose[i]);
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.setLineDash([]);
      ctx.shadowBlur = 0;
    }

    // 5. Highlight 2-Hour Predictive Window
    const predStartIdx = Math.max(0, totalPts - 24); // Last 2 hours (24 * 5min)
    const xPredStart = getX(predStartIdx, totalPts);
    const xPredEnd = getX(totalPts - 1, totalPts);

    ctx.fillStyle = 'rgba(114, 9, 183, 0.18)';
    ctx.fillRect(xPredStart, padTop, xPredEnd - xPredStart, plotH);
    ctx.strokeStyle = 'rgba(181, 23, 158, 0.6)';
    ctx.strokeRect(xPredStart, padTop, xPredEnd - xPredStart, plotH);

    // Predictive Badge
    ctx.font = 'bold 11px Inter, sans-serif';
    ctx.fillStyle = '#f72585';
    ctx.textAlign = 'right';
    ctx.fillText('2-HR PREDICTIVE HORIZON', padLeft + plotW - 10, padTop + 16);

    // 6. X-Axis Time Labels
    ctx.font = '10px Inter, monospace';
    ctx.fillStyle = 'rgba(255, 255, 255, 0.45)';
    ctx.textAlign = 'center';

    const stepInterval = Math.floor(totalPts / 6);
    for (let i = 0; i < totalPts; i += stepInterval) {
      const x = getX(i, totalPts);
      const timeStr = timeline[i] || `${Math.floor((i*5)/60)}:00`;
      ctx.fillText(timeStr, x, padTop + plotH + 18);
    }
  }

  // Real-time sweeping ECG Canvas Monitor
  function initEcgMonitor(canvasId) {
    ecgCanvas = document.getElementById(canvasId);
    if (!ecgCanvas) return;
    ecgCtx = ecgCanvas.getContext('2d');
    resizeCanvas(ecgCanvas);
    startEcgLoop();
  }

  function startEcgLoop() {
    if (ecgAnimId) cancelAnimationFrame(ecgAnimId);
    if (!ecgCanvas || !ecgCtx) return;

    const rect = ecgCanvas.getBoundingClientRect();
    const w = rect.width;
    const h = rect.height;
    const ctx = ecgCtx;

    ctx.fillStyle = '#070b14';
    ctx.fillRect(0, 0, w, h);
    ecgX = 0;
    lastEcgY = h * 0.5;

    let beatPhase = 0;

    function renderEcg() {
      const speed = 2.2;
      const cy = h * 0.5;

      // Clear upcoming band (sweep bar)
      ctx.fillStyle = '#070b14';
      ctx.fillRect(ecgX, 0, 24, h);
      ctx.fillStyle = 'rgba(0, 240, 255, 0.2)';
      ctx.fillRect(ecgX + 22, 0, 2, h);

      // P-Q-R-S-T synthetic heartbeat waveform
      beatPhase = (beatPhase + 0.045) % (Math.PI * 2);
      let wave = 0;
      let phaseInCycle = beatPhase / (Math.PI * 2);

      if (phaseInCycle > 0.20 && phaseInCycle < 0.28) {
        // P-wave
        wave = -8 * Math.sin((phaseInCycle - 0.20) / 0.08 * Math.PI);
      } else if (phaseInCycle > 0.38 && phaseInCycle < 0.40) {
        // Q-dip
        wave = 5;
      } else if (phaseInCycle >= 0.40 && phaseInCycle < 0.45) {
        // R-spike
        wave = -42 * Math.sin((phaseInCycle - 0.40) / 0.05 * Math.PI);
      } else if (phaseInCycle >= 0.45 && phaseInCycle < 0.48) {
        // S-dip
        wave = 12;
      } else if (phaseInCycle > 0.55 && phaseInCycle < 0.68) {
        // T-wave
        wave = -14 * Math.sin((phaseInCycle - 0.55) / 0.13 * Math.PI);
      }

      let targetY = cy + wave;

      ctx.beginPath();
      ctx.strokeStyle = '#00f59b';
      ctx.lineWidth = 1.8;
      ctx.shadowColor = 'rgba(0, 245, 155, 0.7)';
      ctx.shadowBlur = 4;
      ctx.moveTo(ecgX, lastEcgY);
      ctx.lineTo(ecgX + speed, targetY);
      ctx.stroke();
      ctx.shadowBlur = 0;

      lastEcgY = targetY;
      ecgX += speed;
      if (ecgX >= w) ecgX = 0;

      ecgAnimId = requestAnimationFrame(renderEcg);
    }

    renderEcg();
  }

  return {
    initCgmChart,
    drawCgm,
    initEcgMonitor
  };
})();
