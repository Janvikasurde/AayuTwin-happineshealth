/**
 * AAYU-TWIN Anatomical Hologram & Multi-Organ Visualizer
 * Renders an interactive, biophysically responsive medical body avatar
 * with animated organ nodes, stress glows, and organ telemetry drawers.
 */

window.AayuDigitalTwinVis = (function() {
  let activeOrgan = 'pancreas';
  let currentPatient = null;
  let currentMetrics = null;

  const organData = {
    brain: {
      name: "Cerebrovascular & Autonomic Center",
      location: "Neuro-Endocrine Axis",
      getDetails: (p, m) => [
        { label: "Autonomic Tone (HRV RMSSD)", value: `${p.vitalsBaseline.hrvRmssd} ms`, status: p.vitalsBaseline.hrvRmssd < 25 ? "critical" : "normal" },
        { label: "Circadian Sleep Debt", value: `${(7.5 - p.dietaryLifestyleProfile.sleepDurationHours).toFixed(1)} hrs`, status: "warning" },
        { label: "Sympathetic Cortisol Drive", value: `${p.dietaryLifestyleProfile.chronicStressIndex} / 10`, status: "warning" },
        { label: "Nocturnal Stroke Risk", value: "Elevated (Non-Dipper BP)", status: "critical" }
      ],
      description: "Chronic sympathetic overdrive and poor restorative sleep elevate morning cortisol, blunting peripheral insulin receptor sensitivity and increasing early-morning glycemic surges."
    },
    heart: {
      name: "Cardiovascular & Arterial Tree",
      location: "Thorax & Systemic Vasculature",
      getDetails: (p, m) => [
        { label: "Blood Pressure", value: `${m.systolicBpMmHg} / ${m.diastolicBpMmHg} mmHg`, status: m.systolicBpMmHg > 135 ? "critical" : "normal" },
        { label: "Pulse Wave Velocity (PWV)", value: `${p.vitalsBaseline.pulseWaveVelocity} m/s`, status: p.vitalsBaseline.pulseWaveVelocity > 9.0 ? "critical" : "normal" },
        { label: "10-Year QRISK3 CVD Risk", value: `${m.cvdRisk10YearPercent}%`, status: m.cvdRisk10YearPercent > 15 ? "critical" : "warning" },
        { label: "Arterial Compliance (C)", value: `${p.digitalTwinParameters.arterialComplianceC} mL/mmHg`, status: "warning" }
      ],
      description: "Accelerated central arterial stiffness common in the Indian phenotype increases pulse pressure transmission to microvascular beds, accelerating both cardiac hypertrophy and renal damage."
    },
    liver: {
      name: "Hepatic Metabolic Hub",
      location: "Right Upper Abdomen",
      getDetails: (p, m) => [
        { label: "Hepatic Insulin Resistance", value: "High (HOMA-IR " + p.labBiomarkers.homaIr + ")", status: "critical" },
        { label: "Steatosis Probability", value: `${Math.round(p.digitalTwinParameters.hepaticSteatosisProbability * 100)}% (MASLD)`, status: "critical" },
        { label: "Endogenous Glucose Output", value: "Elevated (Nocturnal EGP)", status: "warning" },
        { label: "ALT / AST Ratio", value: `${p.labBiomarkers.liverEnzymes.altSgpt} / ${p.labBiomarkers.liverEnzymes.astSgot} U/L`, status: "warning" }
      ],
      description: "Ectopic lipid deposition in hepatocytes drives unsuppressed overnight hepatic gluconeogenesis, producing the hallmark elevated fasting plasma glucose observed in South Asian patients."
    },
    pancreas: {
      name: "Endocrine Pancreatic Islets",
      location: "Retroperitoneal C-Loop",
      getDetails: (p, m) => [
        { label: "Functional Beta-Cell Capacity", value: `${Math.round(p.digitalTwinParameters.betaCellCapacity * 100)}%`, status: p.digitalTwinParameters.betaCellCapacity < 0.5 ? "critical" : "warning" },
        { label: "Glucotoxicity Stress Index", value: `${m.betaCellStressIndex}`, status: m.betaCellStressIndex > 0.4 ? "critical" : "normal" },
        { label: "HOMA-Beta", value: `${p.labBiomarkers.homaBeta}%`, status: "warning" },
        { label: "Phase-1 Insulin Secretion", value: "Attenuated / Delayed", status: "critical" }
      ],
      description: "Indian phenotype individuals exhibit premature beta-cell exhaustion at 10-15 years younger age than Caucasian cohorts, with accelerated secretory failure under chronic glucotoxicity."
    },
    kidneys: {
      name: "Renal Hemodynamic & Filtration",
      location: "Bilateral Retroperitoneal Space",
      getDetails: (p, m) => [
        { label: "Intraglomerular Hyperfiltration", value: `${m.renalHyperfiltrationStress}x Baseline`, status: m.renalHyperfiltrationStress > 1.3 ? "critical" : "normal" },
        { label: "Estimated GFR (eGFR)", value: `${p.labBiomarkers.estimatedGfr} mL/min/1.73m²`, status: p.labBiomarkers.estimatedGfr < 80 ? "warning" : "normal" },
        { label: "Urine Albumin/Creatinine (UACR)", value: `${p.labBiomarkers.uacr} mg/g`, status: p.labBiomarkers.uacr > 30 ? "critical" : "normal" },
        { label: "SGLT2 Glucosuria Reserve", value: "Available for Modulation", status: "normal" }
      ],
      description: "High intraglomerular capillary hypertension drives microvascular endothelial shear stress, leading to early microalbuminuria and progressive nephron loss if systemic BP and glycemic peaks are unmanaged."
    }
  };

  function init(containerId) {
    const container = document.getElementById(containerId);
    if (!container) return;

    container.innerHTML = `
      <div class="hologram-wrapper">
        <div class="hologram-scanline"></div>
        
        <!-- SVG Anatomical Model -->
        <svg class="anatomical-svg" viewBox="0 0 320 540" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <linearGradient id="bodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stop-color="#00f0ff" stop-opacity="0.15"/>
              <stop offset="50%" stop-color="#0d2149" stop-opacity="0.4"/>
              <stop offset="100%" stop-color="#7928ca" stop-opacity="0.2"/>
            </linearGradient>
            <filter id="glowCyan" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="6" result="blur"/>
              <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
            <filter id="glowWarning" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="8" result="blur"/>
              <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
            <filter id="glowCritical" x="-50%" y="-50%" width="200%" height="200%">
              <feGaussianBlur stdDeviation="10" result="blur"/>
              <feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge>
            </filter>
          </defs>

          <!-- Outer Holographic Grid Ring -->
          <circle cx="160" cy="270" r="230" stroke="#00f0ff" stroke-width="0.75" stroke-dasharray="4 8" opacity="0.3" fill="none" class="pulse-ring"/>
          <circle cx="160" cy="270" r="180" stroke="#7928ca" stroke-width="0.5" stroke-dasharray="6 6" opacity="0.25" fill="none"/>
          
          <!-- Silhouette Body Contours -->
          <g class="body-silhouette" stroke="#00f0ff" stroke-width="1.2" fill="url(#bodyGrad)">
            <!-- Head & Neck -->
            <path d="M142 42 C142 22 178 22 178 42 C178 60 172 74 168 84 L174 94 L146 94 L152 84 C148 74 142 60 142 42 Z" opacity="0.85"/>
            <!-- Torso & Shoulders -->
            <path d="M110 106 C128 96 192 96 210 106 C226 122 222 180 216 230 C212 268 206 295 186 312 L134 312 C114 295 108 268 104 230 C98 180 94 122 110 106 Z" opacity="0.75"/>
            <!-- Arms -->
            <path d="M106 112 L78 210 C74 232 68 265 62 290 C58 296 52 296 50 286 L64 200 L84 116 Z" opacity="0.5"/>
            <path d="M214 112 L242 210 C246 232 252 265 258 290 C262 296 268 296 270 286 L256 200 L236 116 Z" opacity="0.5"/>
            <!-- Pelvis & Legs -->
            <path d="M134 312 L128 410 L122 510 L140 514 L154 416 L158 330 L162 330 L166 416 L180 514 L198 510 L192 410 L186 312 Z" opacity="0.6"/>
          </g>

          <!-- Vascular / Neural Flow Lines -->
          <g class="flow-lines" stroke="#00f0ff" stroke-width="0.8" opacity="0.4" fill="none">
            <line x1="160" y1="94" x2="160" y2="310" stroke-dasharray="3 3"/>
            <path d="M160 160 C135 170 120 195 120 220"/>
            <path d="M160 160 C185 170 200 195 200 220"/>
          </g>

          <!-- Interactive Organ Nodes -->
          <!-- 1. Brain Node -->
          <g class="organ-node" id="node-brain" transform="translate(160, 52)" data-organ="brain" cursor="pointer">
            <circle r="16" class="node-glow glow-brain" fill="#00f0ff" fill-opacity="0.25"/>
            <circle r="7" fill="#00f0ff"/>
            <circle r="2" fill="#ffffff"/>
            <text x="24" y="4" class="node-label" fill="#00f0ff">BRAIN / HRV</text>
          </g>

          <!-- 2. Heart Node -->
          <g class="organ-node" id="node-heart" transform="translate(168, 158)" data-organ="heart" cursor="pointer">
            <circle r="20" class="node-glow glow-heart" fill="#ff2a6d" fill-opacity="0.3"/>
            <circle r="8" fill="#ff2a6d"/>
            <circle r="3" fill="#ffffff"/>
            <text x="26" y="4" class="node-label" fill="#ff2a6d">HEART / BP</text>
          </g>

          <!-- 3. Liver Node -->
          <g class="organ-node" id="node-liver" transform="translate(138, 206)" data-organ="liver" cursor="pointer">
            <circle r="17" class="node-glow glow-liver" fill="#ffb703" fill-opacity="0.25"/>
            <circle r="7" fill="#ffb703"/>
            <circle r="2" fill="#ffffff"/>
            <text x="-85" y="4" class="node-label" fill="#ffb703">LIVER / MASLD</text>
          </g>

          <!-- 4. Pancreas Node -->
          <g class="organ-node active" id="node-pancreas" transform="translate(162, 226)" data-organ="pancreas" cursor="pointer">
            <circle r="19" class="node-glow glow-pancreas" fill="#00f59b" fill-opacity="0.3"/>
            <circle r="8" fill="#00f59b"/>
            <circle r="3" fill="#ffffff"/>
            <text x="26" y="4" class="node-label" fill="#00f59b">PANCREAS</text>
          </g>

          <!-- 5. Kidneys Node -->
          <g class="organ-node" id="node-kidneys" transform="translate(160, 262)" data-organ="kidneys" cursor="pointer">
            <circle r="18" class="node-glow glow-kidneys" fill="#7928ca" fill-opacity="0.3"/>
            <circle r="7" fill="#b5179e"/>
            <circle r="2" fill="#ffffff"/>
            <text x="26" y="4" class="node-label" fill="#b5179e">RENAL / eGFR</text>
          </g>
        </svg>

        <!-- Selected Organ Diagnostic Drawer -->
        <div class="organ-telemetry-panel" id="organDetailBox">
          <!-- Dynamically populated -->
        </div>
      </div>
    `;

    // Attach click listeners to organ nodes
    const nodes = container.querySelectorAll('.organ-node');
    nodes.forEach(node => {
      node.addEventListener('click', () => {
        nodes.forEach(n => n.classList.remove('active'));
        node.classList.add('active');
        activeOrgan = node.getAttribute('data-organ');
        renderOrganDetails();
      });
    });

    renderOrganDetails();
  }

  function update(patient, metrics) {
    currentPatient = patient;
    currentMetrics = metrics;
    updateOrganGlows();
    renderOrganDetails();
  }

  function updateOrganGlows() {
    if (!currentMetrics || !currentPatient) return;

    // Heart glow based on BP & CVD risk
    const heartNode = document.getElementById('node-heart');
    if (heartNode) {
      const glow = heartNode.querySelector('.node-glow');
      if (currentMetrics.systolicBpMmHg > 140 || currentMetrics.cvdRisk10YearPercent > 18) {
        glow.setAttribute('fill', '#ff0055');
        glow.classList.add('pulse-fast');
      } else {
        glow.setAttribute('fill', '#00f59b');
        glow.classList.remove('pulse-fast');
      }
    }

    // Pancreas glow based on beta cell stress
    const pancNode = document.getElementById('node-pancreas');
    if (pancNode) {
      const glow = pancNode.querySelector('.node-glow');
      if (currentMetrics.betaCellStressIndex > 0.45) {
        glow.setAttribute('fill', '#ffb703');
      } else {
        glow.setAttribute('fill', '#00f0ff');
      }
    }
  }

  function renderOrganDetails() {
    const box = document.getElementById('organDetailBox');
    if (!box || !currentPatient || !currentMetrics) return;

    const data = organData[activeOrgan] || organData['pancreas'];
    const items = data.getDetails(currentPatient, currentMetrics);

    let itemsHtml = items.map(item => `
      <div class="organ-stat-row">
        <span class="organ-stat-label">${item.label}</span>
        <span class="organ-stat-value badge-${item.status}">${item.value}</span>
      </div>
    `).join('');

    box.innerHTML = `
      <div class="organ-panel-header">
        <div class="organ-badge">${data.location}</div>
        <h4 class="organ-title">${data.name}</h4>
      </div>
      <div class="organ-stats-grid">
        ${itemsHtml}
      </div>
      <p class="organ-narrative">${data.description}</p>
    `;
  }

  return {
    init,
    update
  };
})();
