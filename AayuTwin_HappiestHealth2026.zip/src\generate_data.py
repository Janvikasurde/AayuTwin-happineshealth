"""
Synthetic Telemetry Generator for AAYU-TWIN
Generates continuous 24-hour time-series (5-minute resolution, 288 points/day)
simulating CGM, PPG/ECG, cuffless BP, and activity streams for 3 patient archetypes.
"""
import json
import math
import numpy as np

def generate_patient_stream(patient_id, base_profile):
    timestamps = []
    cgm_values = []
    hr_values = []
    systolic_bp = []
    diastolic_bp = []
    hrv_values = []
    activity_mets = []
    stress_index = []

    # 288 5-minute ticks in 24 hours (00:00 to 23:55)
    for i in range(288):
        hour = (i * 5) / 60.0
        time_str = f"{int(hour):02d}:{(i*5)%60:02d}"
        timestamps.append(time_str)

        # Circadian baseline rhythms
        # Dawn phenomenon around 4:30 AM - 7:30 AM (hours 4.5 to 7.5)
        dawn_effect = 0
        if 4.5 <= hour <= 7.5:
            dawn_effect = 15.0 * math.sin((hour - 4.5) / 3.0 * math.pi)

        # Meals schedule:
        # Breakfast: 8:30 (hour 8.5)
        # Lunch: 13:30 (hour 13.5)
        # Evening Snack/Chai: 17:30 (hour 17.5)
        # Dinner: 21:30 (hour 21.5) - late dinner typical in urban India
        meal_glucose_spike = 0
        for meal_hour, carb_load, decay in [
            (8.5, 45, 2.2),
            (13.5, 75, 3.0),
            (17.5, 25, 1.5),
            (21.5, 85, 3.5) # Heavy Indian dinner
        ]:
            if hour >= meal_hour:
                dt = hour - meal_hour
                if dt < 4.0:
                    # Gamma-style absorption curve
                    spike = carb_load * 1.6 * (dt / 0.8) * math.exp(-(dt / 0.8))
                    meal_glucose_spike += spike

        # Patient specific modifications
        if patient_id == "IN-P-2026-081": # Rajesh Kumar (Uncontrolled T2D)
            base_g = 155.0
            noise = np.random.normal(0, 4.0)
            glucose = base_g + dawn_effect * 1.5 + meal_glucose_spike * 1.25 + noise
            # Nocturnal non-dipping BP
            base_sys = 142.0
            base_dia = 90.0
            # Stress peaks in afternoon and late evening
            stress = 4.0 + 3.5 * math.sin(hour / 4.0) + (2.0 if 14.0 <= hour <= 20.0 else 0.0)
            hr = 78.0 + (14.0 if 9.0 <= hour <= 19.0 else 0.0) + stress * 1.5 + np.random.normal(0, 2.0)
            hrv = max(14.0, 28.0 - (stress * 1.8) + np.random.normal(0, 1.5))
            sys_bp = base_sys + (stress * 2.2) - (4.0 if 1.0 <= hour <= 5.0 else 0.0) + np.random.normal(0, 2.5)
            dia_bp = base_dia + (stress * 1.2) - (2.0 if 1.0 <= hour <= 5.0 else 0.0) + np.random.normal(0, 1.8)
            met = 1.0 if (hour < 7 or hour > 23) else (1.4 + (0.8 if 18.0 <= hour <= 18.5 else 0.0))

        elif patient_id == "IN-P-2026-144": # Sunita Sharma (Beta-cell decline, renal risk)
            base_g = 168.0
            noise = np.random.normal(0, 3.5)
            # Slower clearance due to impaired beta cells
            glucose = base_g + dawn_effect * 1.2 + meal_glucose_spike * 1.4 + noise
            stress = 3.0 + 2.0 * math.sin(hour / 3.5)
            hr = 74.0 + (8.0 if 8.0 <= hour <= 17.0 else 0.0) + np.random.normal(0, 1.8)
            hrv = max(12.0, 22.0 - stress * 1.2 + np.random.normal(0, 1.2))
            sys_bp = 136.0 + stress * 1.5 - (8.0 if 1.0 <= hour <= 5.0 else 0.0) + np.random.normal(0, 2.0)
            dia_bp = 84.0 + stress * 0.8 - (5.0 if 1.0 <= hour <= 5.0 else 0.0) + np.random.normal(0, 1.5)
            met = 1.0 if (hour < 6 or hour > 22) else 1.2

        else: # Dr. Arjun Nair (Young pre-diabetic, high stress)
            base_g = 104.0
            noise = np.random.normal(0, 3.0)
            # Sharp spikes with hyperinsulinemia rebound
            glucose = base_g + dawn_effect * 0.8 + meal_glucose_spike * 0.85 + noise
            # Occasional reactive hypoglycemia dip around 16:30
            if 16.0 <= hour <= 17.0:
                glucose -= 22.0
            stress = 6.0 + 3.0 * math.sin(hour / 3.0) + (2.5 if 20.0 <= hour <= 23.5 else 0.0)
            hr = 80.0 + (18.0 if 10.0 <= hour <= 22.0 else 0.0) + np.random.normal(0, 3.0)
            hrv = max(18.0, 34.0 - stress * 1.5 + np.random.normal(0, 2.0))
            sys_bp = 126.0 + stress * 1.8 - (10.0 if 1.0 <= hour <= 5.0 else 0.0) + np.random.normal(0, 2.0)
            dia_bp = 82.0 + stress * 1.0 - (7.0 if 1.0 <= hour <= 5.0 else 0.0) + np.random.normal(0, 1.5)
            met = 1.0 if (hour < 6 or hour > 23.5) else (1.8 if 7.0 <= hour <= 7.5 else 1.3)

        cgm_values.append(round(float(glucose), 1))
        hr_values.append(round(float(hr), 1))
        systolic_bp.append(round(float(sys_bp), 1))
        diastolic_bp.append(round(float(dia_bp), 1))
        hrv_values.append(round(float(hrv), 1))
        stress_index.append(round(float(stress), 1))
        activity_mets.append(round(float(met), 2))

    return {
        "patientId": patient_id,
        "samplingIntervalMinutes": 5,
        "totalSamples": 288,
        "timeline": timestamps,
        "cgmMgDl": cgm_values,
        "heartRateBpm": hr_values,
        "systolicBpMmHg": systolic_bp,
        "diastolicBpMmHg": diastolic_bp,
        "hrvRmssdMs": hrv_values,
        "stressIndex": stress_index,
        "activityMets": activity_mets
    }

if __name__ == "__main__":
    patients = ["IN-P-2026-081", "IN-P-2026-144", "IN-P-2026-302"]
    streams = {p: generate_patient_stream(p, {}) for p in patients}
    with open("C:/Users/janvh/.gemini/antigravity-ide/scratch/aayu-digital-twin/data/synthetic_wearable_stream.json", "w") as f:
        json.dump(streams, f, indent=2)
    print("Successfully generated synthetic wearable streams.")
